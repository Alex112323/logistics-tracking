--
-- PostgreSQL database dump
--

\restrict rRfvvc8ErLv3s4mT46tcaQuuHCIBAPTwfFo6Bj9XImfspGSNTfezAL6hv3YKTK2

-- Dumped from database version 16.16 (Debian 16.16-1.pgdg12+1)
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: shipments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shipments (
    tracking_no text NOT NULL,
    status text DEFAULT 'created'::text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT shipments_status_check CHECK ((status = ANY (ARRAY['created'::text, 'in_transit'::text, 'out_for_delivery'::text, 'delivered'::text, 'failed'::text])))
);
ALTER TABLE ONLY public.shipments ALTER COLUMN tracking_no SET (pg_attver=28809872);
ALTER TABLE ONLY public.shipments ALTER COLUMN status SET (pg_attver=28809872);
ALTER TABLE ONLY public.shipments ALTER COLUMN updated_at SET (pg_attver=28809872);


ALTER TABLE public.shipments OWNER TO postgres;

--
-- Data for Name: shipments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shipments (tracking_no, status, updated_at) FROM stdin;
TRK3	created	2026-11-15 10:25:57.462742+00
\.


--
-- Name: shipments shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_pkey PRIMARY KEY (tracking_no);


--
-- PostgreSQL database dump complete
--

\unrestrict rRfvvc8ErLv3s4mT46tcaQuuHCIBAPTwfFo6Bj9XImfspGSNTfezAL6hv3YKTK2

