--
-- PostgreSQL database dump
--

\restrict jCCSivNtDYcvKbxehDlhymJwSvbs3zXMad5QRA5wWXL98ydXRN0a1DCheunHmUg

-- Dumped from database version 16.16 (Debian 16.16-1.pgdg12+1)
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: shipments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shipments (
    tracking_no text NOT NULL,
    status text DEFAULT 'created'::text NOT NULL,
    client_id text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT shipments_status_check CHECK ((status = ANY (ARRAY['created'::text, 'in_transit'::text, 'out_for_delivery'::text, 'delivered'::text, 'failed'::text])))
);
ALTER TABLE ONLY public.shipments ALTER COLUMN tracking_no SET (pg_attver=28838128);
ALTER TABLE ONLY public.shipments ALTER COLUMN status SET (pg_attver=28838128);
ALTER TABLE ONLY public.shipments ALTER COLUMN client_id SET (pg_attver=28838128);
ALTER TABLE ONLY public.shipments ALTER COLUMN updated_at SET (pg_attver=28838128);


ALTER TABLE public.shipments OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    username text NOT NULL,
    hashed_password text NOT NULL,
    role text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT users_role_check CHECK ((role = ANY (ARRAY['admin'::text, 'courier'::text, 'client'::text])))
);
ALTER TABLE ONLY public.users ALTER COLUMN id SET (pg_attver=28813472);
ALTER TABLE ONLY public.users ALTER COLUMN username SET (pg_attver=28813472);
ALTER TABLE ONLY public.users ALTER COLUMN hashed_password SET (pg_attver=28813472);
ALTER TABLE ONLY public.users ALTER COLUMN role SET (pg_attver=28813472);
ALTER TABLE ONLY public.users ALTER COLUMN is_active SET (pg_attver=28813472);
ALTER TABLE ONLY public.users ALTER COLUMN created_at SET (pg_attver=28813472);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: shipments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shipments (tracking_no, status, client_id, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, hashed_password, role, is_active, created_at) FROM stdin;
\.


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: shipments shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_pkey PRIMARY KEY (tracking_no);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: shipments shipments_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.users(username);


--
-- PostgreSQL database dump complete
--

\unrestrict jCCSivNtDYcvKbxehDlhymJwSvbs3zXMad5QRA5wWXL98ydXRN0a1DCheunHmUg

